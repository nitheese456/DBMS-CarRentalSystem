<?php
    include 'db_connection.php';

    session_start();
    // Check if the user is logged in, if not then redirect him to login page
        if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
        header("location: login.php");
        exit;}
        

        //Checking if Cars are available
        $conn = OpenCon();
        $cars_list = $conn->query("SELECT Car_name from car where availability=0");
        $user = $_SESSION['username'];
        $val = 0;
        if(mysqli_num_rows($cars_list)==0){
            $val = 1;
        }

        $val1 = 0;
        $id = $_SESSION['id'];
        $sql7 = "SELECT booking.Booking_id,booking.from_date,booking.to_date,car.Car_name,booking.driver_ref_id,payment.total,payment.balance,payment.discount_applied FROM booking INNER JOIN payment on booking.Booking_id=payment.booking_ref_id INNER JOIN car on booking.car_ref_id=car.Car_id where booking.cust_ref_id='$id'";
        $past_books = $conn->query($sql7);
        if(mysqli_num_rows($past_books)==0){
            $val1 = 1;
        }
        CloseCon($conn);
?>
    
    <html>
    <head>
        <meta charset="utf-8">
        <title>Home page</title>
        <link rel="stylesheet" type="text/css" href="css/homepage.css">

        <script type="text/javascript">
            function booking(){
                var ct = "<?php echo $val ?>";
                if(ct==1){
                  alert("Sorry! No cars are available right now");
                }
                else{
                  window.location.href = "book.php";
                }
            }

            function past(){
                var ct = "<?php echo $val1 ?>";
                if(ct==1){
                  alert("You have not made any bookings with us before !!");
                }
                else{
                  window.location.href = "history.php";
                }
            }

        </script>

    </head>

    <body>
        <img src="images/logo.png" alt="Preview not avaliable" id="logo">
        <header>
            <nav>
                <a href="account.php" id="account">My Account</a>
                <a href="feedback.php" id="feedback">Feedback</a>
                <a href="query.php" id="query">Query</a>
                <a id="history" onclick=past();>History</a>
                <div class="dropdown">
                <button class="dropbtn"><?php echo $user ?> &#9660;</button>
                        <div class="dropdown-content">
                        <a href="logout.php">Logout</a>
                </div>
            </nav>
        </header>

        <div class="main">
       <section class="left">
           <h1 id="h1">Welcome to our </h1>
           <h1 id="h2">Car Rental System</h1>
           <p id="p1">A well developed Car rental company with all varieties of cars.</p>
           <br><br>
           <button class="button" onclick=booking();><span>BOOK NOW</span></button>

           <p id="p2">Credit cards accepted.</p>

       </section> 
       </div>
       
    </body>

</html>