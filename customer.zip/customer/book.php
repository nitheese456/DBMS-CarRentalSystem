<?php
    session_start();
    // Check if the user is logged in, if not then redirect him to login page
        if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
        header("location: login.php");
        exit;}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Booking</title>
  <link rel="stylesheet" type="text/css" href="css/booking.css?v=<?php echo time(); ?>">
  <script type="text/javascript">
    //No_of_days function
    function calculate() {
      var date1 = new Date(document.getElementById('from_date').value);
      var date2 = new Date(document.getElementById('to_date').value);
      var Difference_In_Time = date2.getTime() - date1.getTime(); 
      var Difference_In_Days = Difference_In_Time / (1000 * 3600 * 24); 
      document.getElementById('no_of_days').value = parseInt(Difference_In_Days);
      }

      //Show Driver list
      function showdriver(show_driver) {
        var show = document.getElementById("driver_select");
        show.style.display = show_driver.checked ? "block" : "none";
        }
    
    //Booking Successfull message
    function success() {
        alert("Booking Successfull !!");
      }


   </script>

  <!--Database Connection-->
  <?php
    include 'db_connection.php';
    ?>
</head>
<!--<header>
  <img src="images/book_logo.png">
</header>-->
<body>

  <div class="container">
    <form method="post"  target="_self" >
    
    <h1><p>BOOKING</p></h1>

    <br><br>
  <div class="category">
  <form method="post">
  <label for="category">Car Category</label>
  <input type="radio" id="bronze" value="bronze" name="category" >
  <label for="bronze">Bronze</label>
  <input type="radio" id="silver"  value="silver" name="category" >
  <label for="silver">Silver</label>
  <input type="radio" id="gold"  value="gold" name="category">
  <label for="gold">Gold</label>
  <input type="radio" id="platinum"  value="platinum" name="category">
  <label for="gold">Platinum</label>
  <input type="submit" name="go" value="GO" id="go_button">
  <form>
    </div>
    <br><br>
  <div class="car">
    <label for="car">Car</label>
    <select id="car" name="car">
    
    <!--CAR SELECT-->
    <?php
    $conn = OpenCon();
    if(isset($_POST['go'])){
    $k = $_POST['category'];
    $records = $conn->query("SELECT Car_name FROM Car where category='$k' AND availability=0");
    while ($car = mysqli_fetch_assoc($records)){
          echo "<option>".$car['Car_name']."</option>";
      }}
    CloseCon($conn);
    ?>

    </select>
  </div>
  <br>
  <div class="trip_type">
    <label for="trip">Trip Type</label>
    <select id="trip_type" name="trip_type">
      <option value="Single">Single Trip</option>
      <option value="Round">Round Trip</option>
      <option value="Outstation">Outstation</option>
    </select>
  </div>

  <br>
  <div class="need_driver">
      <label for="need_driver">Need a Driver : </label>
      <input type="checkbox" name="need_driver" id="need_driver" onclick="showdriver(this)"/>
  </div>
  <div id="driver_select" style="display: none">
      <label for="driver">Driver</label>
      <select id="driver" name="driver" style="margin-left: 115px">
      <option value=""></option>

      <!--DRIVER SELECT-->
      <?php
      $conn = OpenCon();
      $drivers = $conn->query("SELECT driver_person.Name,driver.rating FROM driver NATURAL JOIN driver_person WHERE driver.availability=0");
      while ($driver = mysqli_fetch_assoc($drivers)){
          echo "<option>".$driver['Name']."---".$driver['rating'].'/5'."</option>";
      }
      CloseCon($conn);
      ?>
      </select></div>
<br>
  <div class="from_date">
    <label for="from_date">Pickup Date</label>
    <input type="date" name="from_date"  id="from_date" min='27/10/2020' max='27/02/2021'>
  </div>

    <br><br>
    <div class="to_date">
    <label for="to_date">Drop Date</label>
    <input type="date" name="to_date" id="to_date" onchange="calculate()" min='27/10/2020' max='27/02/2021' >
    </div>

    <br><br>
    <div class="no_of_days">
      <label for_numberofdays>Number of Days</label>
      <input type="text" name="no_of_days" id="no_of_days">
    </div>


  <br><br>


  <br>

  <div class="book">
    <input type="submit" name="BOOK" value="BOOK">
  </div>
    
    <!--INSERT IN BOOKING-->
    <?php
      $conn = OpenCon();
    if(isset($_POST['BOOK'])){
      $var1 = $_POST['car'];
      $var2 = $_POST['driver'];
      $var2 = strtok($var2, '-');
      $cu = $_SESSION["id"];

      //Car ID
      $result = $conn->query("SELECT car_id from car WHERE car_name='$var1' ");
      while ($X = mysqli_fetch_assoc($result)){
        $c_id = $X['car_id'];
      }

      //Driver ID
      if ($_POST['driver'] === '')
      {
          $_POST['driver'] = 'NULL';
      }
      else{
      $result = $conn->query("SELECT Driver_id from driver where Adhar_id=(SELECT Adhar_id from driver_person where Name='$var2') ");
      while ($X = mysqli_fetch_assoc($result)){
        $d_id = $X['Driver_id'];
      }}


      //Booking Id
      $b_id = null;
      $row = $conn->query("SELECT Booking_id FROM booking ORDER BY Booking_id DESC LIMIT 1; ");
      while ($X = mysqli_fetch_assoc($row)){
        $b_id = $X['Booking_id'];
      }
      if($b_id == null){
        $b_id ='B01';
      }
      else{
      $bid_num = (int) filter_var($b_id, FILTER_SANITIZE_NUMBER_INT);
      $bid_num = $bid_num+1;
      if($bid_num<10){
      $b_id = 'B0'.$bid_num;
      }
      else{
        $b_id = 'B'.$bid_num;
      }}
      
      //Insert into booking
      $sql = "INSERT INTO booking VALUES(?,?,?,?,?,?,?,?)";
      $stmt = mysqli_prepare($conn,$sql);
      $stmt->bind_param("ssssssss",$b_id,$cu,$c_id,$d_id,$_POST['from_date'], $_POST['to_date'],$_POST['no_of_days'],$_POST['trip_type']);
      
      if(mysqli_stmt_execute($stmt)){
      //Update availability of car 
      $sql4 = "UPDATE car SET availability=1 where Car_id='$c_id'";
      $stmt1 = mysqli_prepare($conn,$sql4);
      $stmt1->execute();

      //Update availability of driver 
      if($d_id != null){
      $sql4 = "UPDATE driver SET availability=1 where Driver_id='$d_id'";
      $stmt2 = mysqli_prepare($conn,$sql4);
      $stmt2->execute();}

      echo "<script type='text/javascript'>alert('Booked :) Remember this id :  '+'$b_id'+'  for payment');</script>";
      }

      CloseCon($conn);
    }

    ?>
  </form>
  <div>
  <button class="gohome" id="gohome" onclick="window.location.href='homepage.php';" ><span>HOME</span></button>
  <div>
</div>
</body>
</html>