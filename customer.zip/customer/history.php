<?php
    include 'db_connection.php';
    session_start();
    // Check if the user is logged in, if not then redirect him to login page
        if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
        header("location: login.php");
        exit;}

    $conn = OpenCon();
    $id = $_SESSION['id'];
    $sql = "SELECT booking.Booking_id,booking.from_date,booking.to_date,car.Car_name,booking.driver_ref_id,payment.total,payment.balance,payment.discount_applied FROM booking INNER JOIN payment on booking.Booking_id=payment.booking_ref_id INNER JOIN car on booking.car_ref_id=car.Car_id where booking.cust_ref_id='$id'";
    $result = $conn->query($sql);

?>
<!DOCTYPE html>
<html>
<head>
<title>History</title>
<style>
body{
background-color:#E6E6FA;
color: rgb(40, 105, 158);
font-family: monospace;
font-size: 25px;
}
table {
border-collapse: collapse;
width: 100%;
color: #ce4949;
font-family: monospace;
font-size: 25px;
text-align: left;
}
th {
background-color: #ce4949;
color: white;
}
tr:nth-child(even) {background-color: #f2f2f2}
</style>
</head>
<body>
<h2>YOUR PAST BOOKINGS :</h2>
<table>
<tr>
<th>Booking_Id</th>
<th>Car</th>
<th>Driver rented</th>
<th>from date</th>
<th>to date</th>
<th>Amount paid</th>
</tr>
<?php
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $sum = $row['total'];
            if($row['discount_applied']==1){
                $sum = $row['balance'];
            }
            $str = "No";
            if($row['driver_ref_id']!=null){
                $str = "Yes";
            }
            echo "<tr><td>" . $row["Booking_id"]. "</td><td>" . $row["Car_name"] . "</td><td>". $str. "</td><td>" . $row["from_date"]. "</td><td>" . $row["to_date"]. "</td><td>" . $sum. "</td></tr>";}
            echo "</table>";
        }   
        else { echo "NO PAST BOOKINGS !!!! <br><br>"; }
        CloseCon($conn);
?>
</table>
</body>
</html>
